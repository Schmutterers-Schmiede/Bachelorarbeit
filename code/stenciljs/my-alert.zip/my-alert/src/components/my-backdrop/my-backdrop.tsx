import {Component} from '@stencil/core';

@Component({
  tag: 'my-backdrop',
  styleUrl: 'my-backdrop.scss'
}) 
export class myBackdrop{
  render(){
    return null
  }
}